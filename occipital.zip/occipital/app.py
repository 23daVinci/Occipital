import os
from flask import Flask, render_template, url_for, request, redirect, flash
from forms import AcceptAnalysis
from flask import Markup
import pandas as pd
import matplotlib.pyplot as plt


######################################

app = Flask(__name__)
app.config['SECRET_KEY'] = 'a354f614d02a1cbf66a3d69528ab2b26'


@app.route("/main")
def main():
    return render_template('main.html')

@app.route("/analysis", methods = ['GET', 'POST'])
def analysis():
    
    #csv
    productCsv = pd.read_csv("data/products.csv")
    j = 0
    pro = []
    unit = []
    newColors = []
    defColors = [
        "#F7464A", "#46BFBD", "#FDB45C", "#FEDCBA",
        "#ABCDEF", "#DDDDDD", "#ABCABC", "#4169E1",
        "#C71585", "#FF4500", "#FEDCBA", "#46BFBD"]
    accu = []
    


    while j <= 3:
        pLable = productCsv.iloc[j, 1]
        pUnit = productCsv.iloc[j, 2]
        accMeasured = productCsv.iloc[j, -1]

        pro.append(pLable)
        unit.append(pUnit)
        c = defColors[j]
        newColors.append(c)
        accu.append(accMeasured)
        j = j + 1

    form = AcceptAnalysis()
    product = False
    if form.validate_on_submit():
        product = form.product.data
        flash (f"you selected {product}")

        # csv
        data_file = pd.read_csv("data/accepted.csv")
        i = 0
        while i <= 2:
            ccheck = data_file.iloc[i, 1]
            if ccheck == product:
                acc = data_file.iloc[i, 3]
                rej = data_file.iloc[i, 4]
                tot = acc + rej
                pAccu = (acc/tot)*100

                labels = [
                    'Accepted', 'Rejected'
                ]

                values = [
                    acc, rej
                ]

                colors = [
                    "#F7464A", "#46BFBD"]

                break
            i = i + 1


        return render_template('analysis.html', form=form,acc=acc,product=product,rej=rej,tot=tot, pAccu=pAccu, max=17000, set=zip(values, labels, colors))

    return render_template('analysis.html', form=form, max=1700, pro=pro, unit=unit, accu=accu)


@app.route("/sorting")
def sorting():
    return render_template('sorting.html')
 
if __name__ == "__main__":
    app.run(debug=True)