from flask import Flask, render_template, url_for
app = Flask(__name__)
 
@app.route("/main")
def main():
    return render_template('main.html')

@app.route("/analysis")
def analysis():
    return render_template('analysis.html')

@app.route("/sorting")
def sorting():
    return render_template('sorting.html')
 
if __name__ == "__main__":
    app.run(debug=True)