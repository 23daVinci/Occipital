from dbs import db, Accept

#mango = Accept('12/8/17', 'Mango', 1)
#banana = Accept('12/8/17', 'banana', 1)

#create all the tables model--> table
my_item = Accept('12/8/17', 'Onion', 4500, 200)
db.session.add(my_item)
db.session.commit()

# delete
#delItem = Testing.query.get(6)
#db.session.delete(delItem)
#db.session.commit()

#db.session.add_all([mango, banana])
#db.session.commit()

all_items = Accept.query.all()
print(all_items)
