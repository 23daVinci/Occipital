from flask_wtf import FlaskForm
from wtforms import SelectField, SubmitField
from wtforms.validators import DataRequired

class AcceptAnalysis(FlaskForm):
    product = SelectField('Product', choices = [('Onion', 'Onion'),('Apple', 'Apple'), ('Banana', 'Banana'), ('Mango', 'Mango')], validators= [DataRequired()])
    submit = SubmitField("Analyse")