import os 
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate

basedir = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///'+os.path.join(basedir, 'data.sqlite')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False 

db = SQLAlchemy(app)
Migrate(app, db)

#################################
class Accept(db.Model):
    # Manual name
    __tablename__ = 'accept'

    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Text)
    product = db.Column(db.Text)
    accept = db.Column(db.Integer)
    reject = db.Column(db.Integer)

    def __init__(self, date, product, accept, reject):
        self.date = date
        self.product = product
        self.accept = accept
        self.reject = reject

    def __repr__(self):
        return f"id: {self.id} date: {self.date} product: {self.product} accepted: {self.accept} reject: {self.reject} ||"